.. _datasets:

==============
Datasets
==============

The :mod:`datasets` submodule contains utilities to download and load datasets
in numpy format.

.. currentmodule:: iced.datasets
